const dns = require('dns').promises

async function check(){
  try{
    console.log('Default servers:', dns.getServers())
  }catch(e){ console.error('getServers err', e) }

  const hosts = ['api.groq.ai','api.openrouter.ai','api.ipify.org']
  for (const h of hosts){
    try{
      const a = await dns.resolve4(h)
      console.log(h, '->', a)
    }catch(e){ console.error(h, 'resolve4 error', e && e.code)}
  }

  console.log('\nTry with Google DNS (8.8.8.8)')
  dns.setServers(['8.8.8.8'])
  for (const h of hosts){
    try{ const a = await dns.resolve4(h); console.log(h, '->', a) }catch(e){ console.error(h, 'g: error', e && e.code) }
  }

  console.log('\nTry with Cloudflare DNS (1.1.1.1)')
  dns.setServers(['1.1.1.1'])
  for (const h of hosts){
    try{ const a = await dns.resolve4(h); console.log(h, '->', a) }catch(e){ console.error(h, 'c: error', e && e.code) }
  }
}

check().catch(e=>{ console.error('dns_check err', e); process.exit(1) })
