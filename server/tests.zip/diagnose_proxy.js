const { HttpsProxyAgent } = require('https-proxy-agent')
const fetch = global.fetch || require('node-fetch')
const tls = require('tls')

const PROXY = 'http://127.0.0.1:10801'

async function fetchWithAgent(url){
  const agent = new HttpsProxyAgent(PROXY)
  try{
    const r = await fetch(url, { method: 'GET', agent, timeout: 20000 })
    const t = await r.text()
    console.log('WITH_AGENT:', url, 'status=', r.status, 'len=', (t||'').length)
    return { ok:true, status: r.status, text: t }
  }catch(e){
    console.error('WITH_AGENT ERROR:', String(e))
    return { ok:false, error: String(e) }
  }
}

async function fetchWithoutAgent(url){
  try{
    const r = await fetch(url, { method: 'GET', timeout: 20000 })
    const t = await r.text()
    console.log('NO_AGENT:', url, 'status=', r.status, 'len=', (t||'').length)
    return { ok:true, status: r.status, text: t }
  }catch(e){
    console.error('NO_AGENT ERROR:', String(e))
    return { ok:false, error: String(e) }
  }
}

function tlsProbe(host, port=443){
  return new Promise((resolve)=>{
    const opts = { host, port, servername: host, rejectUnauthorized: false }
    const s = tls.connect(opts, ()=>{
      console.log('TLS PROBE CONNECTED:', host+':'+port)
      console.log('TLS cipher:', s.getCipher())
      s.end()
      resolve({ ok:true })
    })
    s.setTimeout(10000, ()=>{
      console.error('TLS PROBE TIMEOUT')
      s.destroy()
      resolve({ ok:false, error:'timeout' })
    })
    s.on('error', (err)=>{ console.error('TLS PROBE ERROR:', String(err)); resolve({ ok:false, error: String(err) }) })
  })
}

async function main(){
  const endpoints = [
    'https://api.groq.ai/v1/completions',
    'https://api.openrouter.ai/v1/chat/completions',
    'https://api.ipify.org?format=json'
  ]

  for (const url of endpoints){
    console.log('\n--- Testing', url)
    await fetchWithAgent(url)
    await fetchWithoutAgent(url)
  }

  console.log('\n--- TLS raw probes')
  await tlsProbe('api.groq.ai')
  await tlsProbe('api.openrouter.ai')
}

main().catch(e=>{ console.error('diagnose err', e); process.exit(1) })
