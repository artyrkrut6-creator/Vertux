import fs from 'fs';
import path from 'path';
import { Groq } from 'groq-sdk';
import { HttpsProxyAgent } from 'https-proxy-agent';

async function main(){
  try{
    const keyPath = path.resolve(path.dirname(new URL(import.meta.url).pathname), '..', 'groq_api');
    let apiKey = process.env.GROQ_API_KEY;
    if(!apiKey){
      if(!fs.existsSync(keyPath)){
        console.error('Key file not found:', keyPath);
        process.exit(2);
      }
      apiKey = fs.readFileSync(keyPath, 'utf8').trim();
    }

    if(!apiKey){
      console.error('No GROQ API key provided (env GROQ_API_KEY or groq_api)');
      process.exit(3);
    }

    const proxyUrl = 'http://127.0.0.1:10801';
    const agent = new HttpsProxyAgent(proxyUrl);

    const client = new Groq({
      api_key: apiKey,
      httpAgent: agent,
    });

    console.log(`Connecting to Groq via proxy: ${proxyUrl}...`);

    const chatCompletion = await client.chat.completions.create({
      messages: [
        { role: 'user', content: 'Explain the importance of fast language models' }
      ],
      model: 'llama-3.3-70b-versatile'
    });

    console.log('Success!');
    console.log(chatCompletion.choices?.[0]?.message?.content ?? JSON.stringify(chatCompletion, null, 2));

  }catch(err){
    console.error('Error occurred:');
    console.error(err && err.stack ? err.stack : err);
    process.exit(1);
  }
}

main();
