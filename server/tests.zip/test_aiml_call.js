(async ()=>{
  try{
    const fs = require('fs');
    const key = fs.readFileSync('./aimlapi.com','utf8').trim();
    const url = 'https://api.aimlapi.com/v1/chat/completions';
    const body = {
      model: 'gpt-4o',
      messages: [{ role: 'user', content: 'Write a one-sentence story about numbers.' }]
    };
    console.log('Using key prefix:', key.slice(0,6));
    const resp = await fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${key}` }, body: JSON.stringify(body) });
    const txt = await resp.text();
    console.log('Status', resp.status);
    try{ console.log('JSON:', JSON.parse(txt)) }catch(e){ console.log('Raw:', txt) }
  }catch(e){ console.error('Error', e) }
})();
