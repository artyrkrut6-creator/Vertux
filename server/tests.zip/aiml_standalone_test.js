const fs = require('fs');
const path = require('path');

async function main(){
  try{
    const keyPath = path.resolve(__dirname, '..', 'aimlapi.com');
    let apiKey = process.env.AIMLAPI_KEY;
    if(!apiKey){
      if(!fs.existsSync(keyPath)){
        console.error('Key file not found:', keyPath);
        process.exit(2);
      }
      apiKey = fs.readFileSync(keyPath, 'utf8').trim();
    }

    if(!apiKey){
      console.error('No AIMLAPI key provided (env AIMLAPI_KEY or server/aimlapi.com)');
      process.exit(3);
    }

    const url = 'https://api.aimlapi.com/v1/chat/completions';
    const body = {
      model: 'gpt-4o',
      messages: [
        { role: 'user', content: 'Hello' }
      ]
    };

    console.log('Calling AimlAPI chat/completions (no proxy)...');

    const res = await fetch(url, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${apiKey}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(body),
    });

    console.log('HTTP', res.status, res.statusText);
    const text = await res.text();
    try{
      const json = JSON.parse(text);
      console.log(JSON.stringify(json, null, 2));
    }catch(e){
      console.log(text);
    }
  }catch(err){
    console.error('Error:', err && err.stack ? err.stack : err);
    process.exit(1);
  }
}

main();
