const fs = require('fs')
const path = require('path')

const OUT_DIR = path.join(__dirname, 'results')
if (!fs.existsSync(OUT_DIR)) fs.mkdirSync(OUT_DIR, { recursive: true })

async function postJson(url, json){
  const resp = await fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(json), timeout: 60000 })
  const text = await resp.text()
  return { status: resp.status, body: text }
}

async function testGroqCompletions(){
  try{
    const url = 'http://127.0.0.1:5176/api/groq/completions'
    const payload = { prompt: 'Short BTC summary', max_completion_tokens: 120 }
    const r = await postJson(url, payload)
    fs.writeFileSync(path.join(OUT_DIR, 'groq_completions.json'), JSON.stringify(r, null, 2))
    console.log('groq_completions:', r.status)
  }catch(e){ fs.writeFileSync(path.join(OUT_DIR, 'groq_completions_error.txt'), String(e)); console.error('groq error', e) }
}

async function testGroqStream(){
  try{
    const url = 'http://127.0.0.1:5176/api/groq/stream'
    const payload = { prompt: 'Short BTC summary (stream)', max_completion_tokens: 512 }
    const resp = await fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload), timeout: 120000 })
    const chunks = []
    if (!resp || !resp.body) throw new Error('no response body')
    for await (const chunk of resp.body){
      try{ chunks.push(Buffer.from(chunk).toString('utf8')) }catch(e){ /* ignore */ }
      if (chunks.join('').length > 2000) break
    }
    const out = { status: resp.status, collected: chunks.join('') }
    fs.writeFileSync(path.join(OUT_DIR, 'groq_stream.json'), JSON.stringify(out, null, 2))
    console.log('groq_stream:', resp.status)
  }catch(e){ fs.writeFileSync(path.join(OUT_DIR, 'groq_stream_error.txt'), String(e)); console.error('groq stream error', e) }
}

async function testOpenrouterDeepseek(){
  try{
    const url = 'http://127.0.0.1:5176/api/openrouter/deepseek'
    const payload = { messages: [{ role: 'user', content: 'Short BTC summary' }], reasoning: true }
    const r = await postJson(url, payload)
    fs.writeFileSync(path.join(OUT_DIR, 'openrouter_deepseek.json'), JSON.stringify(r, null, 2))
    console.log('openrouter_deepseek:', r.status)
  }catch(e){ fs.writeFileSync(path.join(OUT_DIR, 'openrouter_deepseek_error.txt'), String(e)); console.error('openrouter error', e) }
}

async function testDeepsikQA(){
  try{
    const url = 'http://127.0.0.1:5176/api/deepsik/qa'
    const payload = { question: 'What is the short-term sentiment?', symbol: 'BTCUSDT' }
    const r = await postJson(url, payload)
    fs.writeFileSync(path.join(OUT_DIR, 'deepsik_qa.json'), JSON.stringify(r, null, 2))
    console.log('deepsik_qa:', r.status)
  }catch(e){ fs.writeFileSync(path.join(OUT_DIR, 'deepsik_qa_error.txt'), String(e)); console.error('deepsik qa error', e) }
}

async function main(){
  console.log('Starting tests — results in', OUT_DIR)
  // wait for local proxy to be available
  const maxWait = 10000
  const start = Date.now()
  while(true){
    try{
      const r = await fetch('http://127.0.0.1:5176/')
      if (r && r.ok) break
    }catch(e){ /* not ready */ }
    if (Date.now() - start > maxWait) break
    await new Promise(r=>setTimeout(r, 250))
  }

  await testGroqCompletions()
  await testGroqStream()
  await testOpenrouterDeepseek()
  await testDeepsikQA()
  console.log('Tests complete')
}

main().catch(e=>{ console.error('run tests error', e); process.exit(1) })
